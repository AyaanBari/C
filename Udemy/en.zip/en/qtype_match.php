<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'qtype_match', language 'en', version '2.0'.
 *
 * @package     qtype_match
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addingmatch'] = 'Adding a Matching question';
$string['addmoreqblanks'] = '{no} More Sets of Blanks';
$string['editingmatch'] = 'Editing a Matching question';
$string['filloutthreeqsandtwoas'] = 'You must provide at least two questions and three answers. You can provide extra wrong answers by giving an answer with a blank question. Entries where both the question and the answer are blank will be ignored.';
$string['match'] = 'Matching';
$string['match_help'] = 'Matching questions require the respondent to correctly match a list of names or statements (questions) to another list of names or statements (answers).';
$string['match_link'] = 'question/type/match';
$string['matchsummary'] = 'The answer to each of a number of sub-question must be selected from a list of possibilities.';
$string['nomatchinganswerforq'] = 'You must specify an answer for this question.';
$string['notenoughqsandas'] = 'You must supply at least {$a->q} questions and {$a->a} answers.';
$string['notenoughquestions'] = 'You must supply at least {$a} question and answer pairs.';
$string['shuffle'] = 'Shuffle';
$string['shuffle_help'] = 'If enabled, the order of the statements (answers) is randomly shuffled for each attempt, provided that "Shuffle within questions" in the quiz settings is also enabled.';
